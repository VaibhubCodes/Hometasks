from django.db import models
from django.utils import timezone
from django.conf import settings  # Use this to refer to the custom user model

class Task(models.Model):
    name = models.CharField(max_length=100, default="Default Task Name")
    description = models.TextField()
    upload_date = models.DateTimeField(auto_now_add=True)
    priority = models.CharField(max_length=6, choices=[
        ('LOW', 'Low'),
        ('MEDIUM', 'Medium'),
        ('HIGH', 'High'),
    ], default='LOW')
    completed = models.BooleanField(default=False)
    completion_date = models.DateTimeField(null=True, blank=True)
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        related_name='assigned_tasks',
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    completed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        related_name='completed_tasks',
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    task_done = models.BooleanField(default=False)  # New field to indicate if the task is done

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if self.completed and not self.completion_date:
            self.completion_date = timezone.now()
        super(Task, self).save(*args, **kwargs)
