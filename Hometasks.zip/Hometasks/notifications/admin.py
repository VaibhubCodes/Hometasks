from django.contrib import admin
from django.forms import ModelForm, ValidationError
from .models import DeviceToken, Notification
from .utils import send_push_notification  # Ensure this utility is correctly defined

# Form for custom validation or actions for Notification
class NotificationAdminForm(ModelForm):
    class Meta:
        model = Notification
        fields = '__all__'

    def clean(self):
        cleaned_data = super().clean()
        # Add custom validation if needed
        return cleaned_data

# Admin for DeviceToken
@admin.register(DeviceToken)
class DeviceTokenAdmin(admin.ModelAdmin):
    list_display = ('user', 'token', 'created_at', 'updated_at')  # Display fields
    search_fields = ('user__phone', 'token')  # Adjust search to use phone

# Admin for Notification
@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    form = NotificationAdminForm
    list_display = ('title', 'message', 'sent_to', 'sent', 'created_at')  # Fields to display
    list_filter = ('sent', 'created_at')  # Filters
    actions = ['send_notification']  # Custom actions

    def send_notification(self, request, queryset):
        for notification in queryset:
            if not notification.sent:
                # Retrieve the last registered device token for the user
                token = notification.sent_to.device_tokens.last()
                if token:
                    result = send_push_notification(token.token, notification.title, notification.message)
                    notification.sent = True
                    notification.save()
                    self.message_user(request, f'Successfully sent notification to {notification.sent_to.phone}')
                else:
                    self.message_user(request, f'No device token found for {notification.sent_to.phone}', level='error')
            else:
                self.message_user(request, f'Notification already sent to {notification.sent_to.phone}', level='warning')
    send_notification.short_description = "Send selected notifications"

