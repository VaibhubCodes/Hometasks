# notifications/utils.py
from pyfcm import FCMNotification

def send_push_notification(token, title, message):
    push_service = FCMNotification(api_key="BMPCK-8w2Zh6ixHwKCSGnFbE_G8NTEm2Bj8lmZOOzje-czOIInTImSpPfp2hPlt9u772yD7Vg6-NDkYNxtL_12M")
    result = push_service.notify_single_device(registration_id=token, message_title=title, message_body=message)
    return result
