from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Task
from notifications.utils import send_push_notification

@receiver(post_save, sender=Task)
def send_notification_to_user(sender, instance, created, **kwargs):
    if created:
        token = instance.assigned_to.fcm_token  # Assuming `fcm_token` is stored in the User model
        if token:
            send_push_notification(token, "New Task Assigned", f"{instance.name} - {instance.description}")
