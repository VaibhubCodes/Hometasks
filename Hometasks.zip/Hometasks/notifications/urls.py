from django.urls import path
from .views import RegisterToken, SendNotification

urlpatterns = [
    path('register-token/', RegisterToken.as_view(), name='register-token'),
    path('send-notification/', SendNotification.as_view(), name='send-notification'),
]
